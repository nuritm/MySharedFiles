
python3 generateDBs.py
python3 runDiffChunkSizes.py


